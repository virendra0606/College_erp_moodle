<?php
// Capabilities for local_erpsso.

defined('MOODLE_INTERNAL') || die();

$capabilities = [
    // Needed by the web service user that the ERP uses. Site admins have it automatically.
    'local/erpsso:logoutusers' => [
        'captype' => 'write',
        'contextlevel' => CONTEXT_SYSTEM,
        'archetypes' => [],
    ],
];