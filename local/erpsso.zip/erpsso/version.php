<?php
// This file is part of the local_erpsso plugin (ERP single logout for Moodle).

defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_erpsso';
$plugin->version   = 2026111100;
$plugin->requires  = 2024100700; // Moodle 4.5.
$plugin->maturity  = MATURITY_STABLE;
$plugin->release   = '1.0';