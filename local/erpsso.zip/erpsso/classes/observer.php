<?php
// Tells the ERP when a user logs out of Moodle.

namespace local_erpsso;

defined('MOODLE_INTERNAL') || die();

/**
 * Event observer: Moodle logout -> signed server-to-server call to the ERP.
 */
class observer {
    /**
     * Called when a user logs out of Moodle.
     *
     * @param \core\event\user_loggedout $event
     */
    public static function user_loggedout(\core\event\user_loggedout $event): void {
        global $DB, $CFG;
        require_once($CFG->libdir . '/filelib.php');

        $erpurl = rtrim((string) get_config('local_erpsso', 'erpurl'), '/');
        $secret = (string) get_config('local_erpsso', 'secret');
        if ($erpurl === '' || $secret === '') {
            return; // Not configured: do nothing.
        }

        $user = $DB->get_record('user', ['id' => $event->objectid], 'id, username, deleted');
        if (!$user || $user->deleted) {
            return;
        }

        // Signature format must match the ERP: HMAC-SHA256 of "<username>|<timestamp>" with the shared secret.
        $timestamp = time();
        $signature = hash_hmac('sha256', $user->username . '|' . $timestamp, $secret);

        try {
            $curl = new \curl();
            // Short timeouts: a slow ERP must never make Moodle logout hang.
            $curl->setopt(['CURLOPT_TIMEOUT' => 3, 'CURLOPT_CONNECTTIMEOUT' => 2]);
            $curl->post($erpurl . '/oauth/logout/backchannel/', [
                'username' => $user->username,
                'ts' => $timestamp,
                'sig' => $signature,
            ]);
            if ($curl->get_errno()) {
                debugging('local_erpsso: ERP logout call failed: ' . $curl->error, DEBUG_DEVELOPER);
            }
        } catch (\Throwable $e) {
            debugging('local_erpsso: ' . $e->getMessage(), DEBUG_DEVELOPER);
        }
    }
}