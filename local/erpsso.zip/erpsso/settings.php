<?php
// Admin settings for local_erpsso.

defined('MOODLE_INTERNAL') || die();

if ($hassiteconfig) {
    $settings = new admin_settingpage('local_erpsso', get_string('pluginname', 'local_erpsso'));
    $ADMIN->add('localplugins', $settings);

    $settings->add(new admin_setting_configtext(
        'local_erpsso/erpurl',
        get_string('erpurl', 'local_erpsso'),
        get_string('erpurl_desc', 'local_erpsso'),
        '',
        PARAM_URL
    ));

    $settings->add(new admin_setting_configpasswordunmask(
        'local_erpsso/secret',
        get_string('secret', 'local_erpsso'),
        get_string('secret_desc', 'local_erpsso'),
        ''
    ));
}