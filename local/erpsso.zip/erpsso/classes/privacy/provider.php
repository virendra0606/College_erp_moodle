<?php
// Privacy API implementation for local_erpsso.

namespace local_erpsso\privacy;

defined('MOODLE_INTERNAL') || die();

use core_privacy\local\metadata\collection;

/**
 * The plugin stores nothing, but it sends the username to the ERP on logout.
 */
class provider implements \core_privacy\local\metadata\provider {
    /**
     * Describes the external data transfer.
     *
     * @param collection $collection
     * @return collection
     */
    public static function get_metadata(collection $collection): collection {
        $collection->add_external_location_link('erp', [
            'username' => 'privacy:metadata:erp:username',
        ], 'privacy:metadata:erp');
        return $collection;
    }
}