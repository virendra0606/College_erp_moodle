<?php
// Language strings for local_erpsso.

defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'ERP single logout';
$string['erpurl'] = 'ERP base URL';
$string['erpurl_desc'] = 'Public https address of the ERP, for example https://erp.example.com (no trailing path). When a user logs out of Moodle, this plugin tells the ERP to end the same user\'s ERP sessions.';
$string['secret'] = 'Shared secret';
$string['secret_desc'] = 'Must be exactly the same value as SSO_BACKCHANNEL_SECRET in the ERP .env file. Keep it long and random.';
$string['erpsso:logoutusers'] = 'Log users out of Moodle on behalf of the ERP (single logout)';
$string['privacy:metadata:erp'] = 'When a user logs out of Moodle, their username is sent to the ERP so that the ERP can end the same user\'s sessions.';
$string['privacy:metadata:erp:username'] = 'The Moodle username of the user who logged out.';